﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using ChrisAkridge.Common.Validation;

namespace ChrisAkridge.Common
{
    public sealed class ExpandableMemoryStream : Stream
    {
        // A memory stream backed by a List<byte> with an initial capacity of 65,536 bytes.
        // Has Read/Write methods for integer types, floating/decimal types, byte arrays, and other streams.
        // Constructor also specifies endianness.

        private readonly List<byte> memory;
        private int position;
        
        public Endianness Endianness { get; }
        public override bool CanRead => true;
        public override bool CanSeek => true;
        public override bool CanWrite => true;
        public override long Length => memory.Count;

        public override long Position
        {
            get => position;
            set
            {
                Validate.Begin().InRangeInclusive(0, Length - 1, value, nameof(value)).Check();

                position = (int)value;
            }
        }

        private bool IsLittleEndian => Endianness == Endianness.LittleEndian;

        public ExpandableMemoryStream() : this(Endianness.LittleEndian, 65536) { }
        
        public ExpandableMemoryStream(Endianness endianness) : this(endianness, 65536) { }

        public ExpandableMemoryStream(Endianness endianness, int initialCapacity)
        {
            Endianness = endianness;
            memory = new List<byte>(initialCapacity);
        }

        public override void Flush() => throw new InvalidOperationException("This stream is written directly without flushing.");

        public override int Read(byte[] buffer, int offset, int count)
        {
            Validate.Begin().IsNotNull(buffer, nameof(buffer))
                    .InRangeInclusive(0, buffer.Length - 1, offset, nameof(offset))
                    .IsNotNegative(offset, nameof(offset))
                    .InRangeInclusive(1, buffer.Length, offset + count, "offset + count").Check();

            int bufferOffset = offset;
            int read = 0;

            while (count > 0)
            {
                buffer[bufferOffset] = memory[position];

                bufferOffset += 1;
                position += 1;
                read += 1;
                count -= 1;
            }

            return read;
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            Validate.Begin().IsValidEnumValue(origin, nameof(origin))
                    .InRangeInclusive(0, Length - 1, offset, nameof(offset)).Check();

            Position = (origin == SeekOrigin.Begin) ? offset : Length - offset;

            return Position;
        }

        public override void SetLength(long value)
        {
            throw new InvalidOperationException("Expandable memory streams automatically expand their capacity; this does not need to be done manually.");
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            Validate.Begin().IsNotNull(buffer, nameof(buffer))
                    .InRangeInclusive(0, buffer.Length - 1, offset, nameof(offset))
                    .IsNotNegative(count, nameof(count))
                    .InRangeInclusive(1, buffer.Length, offset + count, "offset + count").Check();

            int bufferOffset = offset;

            while (count > 0)
            {
                WriteByte(buffer[bufferOffset]);

                bufferOffset++;
                count--;
            }
        }

        public override int ReadByte()
        {
            if (position == memory.Count)
            {
                throw new IndexOutOfRangeException("Cannot read past the end of the memory stream.");
            }

            byte b = memory[position];
            position += 1;

            return b;
        }

        public sbyte ReadSByte() => unchecked((sbyte) ReadByte());

        public ushort ReadUInt16()
        {
            if (position >= memory.Count - 1)
            {
                throw new IndexOutOfRangeException("Cannot read past the end of the memory stream.");
            }

            byte high = (IsLittleEndian) ? memory[position + 1] : memory[position];
            byte low = (IsLittleEndian) ? memory[position] : memory[position + 1];

            position += 2;
            
            return (ushort) ((high << 8) | low);
        }

        public short ReadInt16() => unchecked((short) ReadUInt16());

        public uint ReadUInt32()
        {
            if (position >= memory.Count - 3)
            {
                throw new IndexOutOfRangeException("Cannot read past the end of the memory stream.");
            }

            byte a = (IsLittleEndian) ? memory[position + 3] : memory[position];
            byte b = (IsLittleEndian) ? memory[position + 2] : memory[position + 1];
            byte c = (IsLittleEndian) ? memory[position + 1] : memory[position + 2];
            byte d = (IsLittleEndian) ? memory[position] : memory[position + 3];

            position += 4;

            return (uint) ((a << 24) | (b << 16) | (c << 8) | d);
        }

        public int ReadInt32() => unchecked((int) ReadUInt32());

        public ulong ReadUInt64()
        {
            if (position >= memory.Count - 7)
            {
                throw new IndexOutOfRangeException("Cannot read past the end of the memory stream.");
            }

            byte a = (IsLittleEndian) ? memory[position + 7] : memory[position];
            byte b = (IsLittleEndian) ? memory[position + 6] : memory[position + 1];
            byte c = (IsLittleEndian) ? memory[position + 5] : memory[position + 2];
            byte d = (IsLittleEndian) ? memory[position + 4] : memory[position + 3];
            byte e = (IsLittleEndian) ? memory[position + 3] : memory[position + 4];
            byte f = (IsLittleEndian) ? memory[position + 2] : memory[position + 5];
            byte g = (IsLittleEndian) ? memory[position + 1] : memory[position + 6];
            byte h = (IsLittleEndian) ? memory[position] : memory[position + 7];

            uint high = (uint) ((a << 24) | (b << 16) | (c << 8) | d);
            uint low = (uint) ((e << 24) | (f << 16) | (g << 8) | h);

            position += 8;

            return ((ulong)high << 32) | low;
        }

        public long ReadInt64() => unchecked((long) ReadUInt64());

        public float ReadSingle()
        {
            if (position >= memory.Count - 3)
            {
                throw new IndexOutOfRangeException("Cannot read past the end of the memory stream.");
            }

            var floatBytes = new byte[4];

            floatBytes[0] = (IsLittleEndian) ? memory[position + 3] : memory[position];
            floatBytes[1] = (IsLittleEndian) ? memory[position + 2] : memory[position + 1];
            floatBytes[2] = (IsLittleEndian) ? memory[position + 1] : memory[position + 2];
            floatBytes[3] = (IsLittleEndian) ? memory[position] : memory[position + 3];

            position += 4;

            return BitConverter.ToSingle(floatBytes, 0);
        }

        public double ReadDouble() => BitConverter.Int64BitsToDouble(ReadInt64());

        public override void WriteByte(byte value)
        {
            if (position == memory.Count)
            {
                memory.Add(value);
            }
            else { memory[position] = value; }

            position++;
        }

        public void WriteSByte(sbyte value)
        {
            unchecked { WriteByte((byte) value); }
        }

        public void WriteUInt16(ushort value)
        {
            byte high = (byte)(value >> 8);
            byte low = (byte) value;
            
            WriteByte((IsLittleEndian) ? low : high);
            WriteByte((IsLittleEndian) ? high : low);
        }

        public void WriteInt16(short value)
        {
            unchecked { WriteUInt16((ushort)value); }
        }

        public void WriteUInt32(uint value)
        {
            byte a = (byte) (value >> 24);
            byte b = (byte) ((value >> 16) & 0xFF);
            byte c = (byte) ((value >> 8) & 0xFF);
            byte d = (byte) value;
            
            WriteByte((IsLittleEndian) ? d : a);
            WriteByte((IsLittleEndian) ? c : b);
            WriteByte((IsLittleEndian) ? b : c);
            WriteByte((IsLittleEndian) ? a : d);
        }

        public void WriteInt32(int value)
        {
            unchecked { WriteUInt32((uint) value); }
        }

        public void WriteUInt64(ulong value)
        {
            byte a = (byte) ((value >> 56) & 0xFF);
            byte b = (byte) ((value >> 48) & 0xFF);
            byte c = (byte) ((value >> 40) & 0xFF);
            byte d = (byte) ((value >> 32) & 0xFF);
            byte e = (byte) ((value >> 24) & 0xFF);
            byte f = (byte) ((value >> 16) & 0xFF);
            byte g = (byte) ((value >> 8) & 0xFF);
            byte h = (byte) value;
            
            WriteByte((IsLittleEndian) ? h : a);
            WriteByte((IsLittleEndian) ? g : b);
            WriteByte((IsLittleEndian) ? f : c);
            WriteByte((IsLittleEndian) ? e : d);
            WriteByte((IsLittleEndian) ? d : e);
            WriteByte((IsLittleEndian) ? c : f);
            WriteByte((IsLittleEndian) ? b : g);
            WriteByte((IsLittleEndian) ? a : h);
        }

        public void WriteInt64(long value)
        {
            unchecked
            {
                WriteUInt64((ulong) value);
            }
        }

        public void WriteSingle(float value)
        {
            byte[] floatBytes = BitConverter.GetBytes(value);

            WriteByte((IsLittleEndian) ? floatBytes[3] : floatBytes[0]);
            WriteByte((IsLittleEndian) ? floatBytes[2] : floatBytes[1]);
            WriteByte((IsLittleEndian) ? floatBytes[1] : floatBytes[2]);
            WriteByte((IsLittleEndian) ? floatBytes[0] : floatBytes[3]);
        }

        public void WriteDouble(double value)
        {
            WriteInt64(BitConverter.DoubleToInt64Bits(value));
        }
    }

    public enum Endianness
    {
        LittleEndian,
        BigEndian
    }
}
