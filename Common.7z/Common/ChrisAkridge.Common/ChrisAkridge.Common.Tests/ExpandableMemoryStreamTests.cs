﻿using System;
using ChrisAkridge.Common.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ChrisAkridge.Common.Tests
{
    [TestClass]
    public class ExpandableMemoryStreamTests
    {
        [TestMethod]
        public void LittleEndianTests()
        {
            var stream = new ExpandableMemoryStream(Endianness.LittleEndian, 1024);
            
            var writeBytes = new byte[] {0x00, 0x40, 0x80, 0xC0};
            stream.Write(writeBytes, 0, 4);
            stream.WriteByte(137);
            stream.WriteSByte(-20);
            stream.WriteUInt16(32768);
            stream.WriteUInt32(1073741824);
            stream.WriteUInt64(25_000_000_000_000_000);
            stream.WriteInt16(-137);
            stream.WriteInt32(-1_234_567_890);
            stream.WriteInt64(-12_500_000_000_000_000);
            stream.WriteSingle(3.14159f);
            stream.WriteDouble(Math.PI);

            stream.Position = 0;
            var readBytes = new byte[4];
            stream.Read(readBytes, 0, 4);
            
            Assert.AreEqual(0x00, readBytes[0]);
            Assert.AreEqual(0x40, readBytes[1]);
            Assert.AreEqual(0x80, readBytes[2]);
            Assert.AreEqual(0xC0, readBytes[3]);
            
            Assert.AreEqual(137, stream.ReadByte());
            Assert.AreEqual(-20, stream.ReadSByte());
            Assert.AreEqual(32768u, stream.ReadUInt16());
            Assert.AreEqual(1073741824u, stream.ReadUInt32());
            Assert.AreEqual(25_000_000_000_000_000u, stream.ReadUInt64());
            Assert.AreEqual(-137, stream.ReadInt16());
            Assert.AreEqual(-1_234_567_890, stream.ReadInt32());
            Assert.AreEqual(-12_500_000_000_000_000, stream.ReadInt64());
            Assert.IsTrue(3.14159f.NearlyEqual(stream.ReadSingle(), 0.0001f));
            Assert.IsTrue(Math.PI.NearlyEqual(stream.ReadDouble(), 1e-10d));
        }

        [TestMethod]
        public void BigEndianTests()
        {
            var stream = new ExpandableMemoryStream(Endianness.BigEndian, 1024);

            var writeBytes = new byte[] {0x00, 0x40, 0x80, 0xC0};
            stream.Write(writeBytes, 0, 4);
            stream.WriteByte(137);
            stream.WriteSByte(-20);
            stream.WriteUInt16(32768);
            stream.WriteUInt32(1073741824);
            stream.WriteUInt64(25_000_000_000_000_000);
            stream.WriteInt16(-137);
            stream.WriteInt32(-1_234_567_890);
            stream.WriteInt64(-12_500_000_000_000_000);
            stream.WriteSingle(3.14159f);
            stream.WriteDouble(Math.PI);

            stream.Position = 0;
            var readBytes = new byte[4];
            stream.Read(readBytes, 0, 4);

            Assert.AreEqual(0x00, readBytes[0]);
            Assert.AreEqual(0x40, readBytes[1]);
            Assert.AreEqual(0x80, readBytes[2]);
            Assert.AreEqual(0xC0, readBytes[3]);

            Assert.AreEqual(137, stream.ReadByte());
            Assert.AreEqual(-20, stream.ReadSByte());
            Assert.AreEqual(32768u, stream.ReadUInt16());
            Assert.AreEqual(1073741824u, stream.ReadUInt32());
            Assert.AreEqual(25_000_000_000_000_000u, stream.ReadUInt64());
            Assert.AreEqual(-137, stream.ReadInt16());
            Assert.AreEqual(-1_234_567_890, stream.ReadInt32());
            Assert.AreEqual(-12_500_000_000_000_000, stream.ReadInt64());
            Assert.IsTrue(3.14159f.NearlyEqual(stream.ReadSingle(), 0.0001f));
            Assert.IsTrue(Math.PI.NearlyEqual(stream.ReadDouble(), 1e-10d));
        }
    }
}
