# ChrisAkridge.Common

**A library containing common code and utilities for my projects.**

The project is licensed under the MIT license, so feel free to use this in your own projects.